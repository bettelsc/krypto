/**
 * @author Niklas Hock
 */
package encode;