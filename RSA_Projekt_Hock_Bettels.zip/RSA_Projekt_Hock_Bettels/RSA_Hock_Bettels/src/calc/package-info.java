/**
 * @author Constantin Bettels
 */
package calc;