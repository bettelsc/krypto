/**
 * @author Niklas Hock
 */
package attack;